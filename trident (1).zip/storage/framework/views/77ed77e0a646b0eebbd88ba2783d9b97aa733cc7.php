<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row ">
            <?php if(Auth::guard('web')->user()->can('Registration')): ?>
            <div class="col-md-6  w-50 " >
                <div class="p-2" style="margin:2px;">
                    <p class="h5 text-white bg-dark w-100 p-3 d-flex justify-content-between">Registration <i class="fa-solid fa-address-card h2 text-light"></i></p>
                    <?php if(Auth::guard('web')->user()->can('Registration Create')): ?>
                    <a class="m-3 text-decoration-none" href="<?php echo e(route('warrenty.add.registration')); ?>">Start new registration</a> <br>
                    <?php endif; ?>
                    <hr>
                     <?php if(Auth::guard('web')->user()->can('Registration Create')): ?>
                    <a class="m-3" href="<?php echo e(route('search.view')); ?>">Search / Edit registrations</a>
                    <?php endif; ?>
                    <hr>
                </div>
            </div>
            <?php endif; ?>
            <?php if(Auth::guard('web')->user()->can('Claim')): ?>
            <div class="col-md-6   w-50 " >
                <div class="p-2" style="margin:2px;">
                    <p class="h5 text-white bg-dark w-100 p-3 d-flex justify-content-between">Claim <i class="fa-regular fa-id-card h2 text-light"></i></p>
                    <a class="m-3 text-decoration-none" href="<?php echo e(route('newClaim')); ?>">New Claim</a> <br>
                    <hr>
                    <a class="m-3" href="<?php echo e(route('allClaim')); ?>">All Claim</a>
                    <hr>
                </div>
            </div>
            <?php endif; ?>
            <?php if(Auth::guard('web')->user()->can('Service Create')): ?>
            <div class="col-md-6 w-50">
                <div class="p-2" style="margin:2px;">
                    <p class="h5 text-white bg-dark w-100 p-3 d-flex justify-content-between">Service Create<i class="fa-solid fa-screwdriver-wrench h2 text-light"></i></p>
                    <a class="m-3 text-decoration-none" href="<?php echo e(route('create_service')); ?>">Create Service</a> <br>
                    <hr>
                    <a href="#">&nbsp</a>
                    <hr>
                    <a href="#">&nbsp</a>
                    <hr>
                </div>
            </div>
            <?php endif; ?>
        
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/warrenty/home.blade.php ENDPATH**/ ?>