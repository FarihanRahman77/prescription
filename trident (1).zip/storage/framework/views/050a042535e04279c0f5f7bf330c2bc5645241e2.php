<table style="table-layout: auto;width: 100%;">
	<thead>
	    	<tr><td colspan="13" style="text-align: center;"> <?php echo e(@$setting->name); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> <?php echo e(@$setting->address); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Hotline: <?php echo e(@$setting->phone); ?></td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Email: <?php echo e(@$setting->email); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Fax: <?php echo e(@$setting->fax); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> </td></tr>
		<tr>
            <th style="text-align:center;">Sl</th>
            <th style="text-align:center;">Date</th>
            <th style="text-align:center;">Service No</th>
            <th style="text-align:center;">Hours Run</th>
            <th style="text-align:center;">Comission Date</th>
            <th style="text-align:center;">Work Done Date</th>
            <th style="text-align:center;">Customer Company Name</th>
            <th style="text-align:center;">Customer Mobile</th>
            <th style="text-align:center;">Product Serial</th>
            <th style="text-align:center;">Product Category</th>
            <th style="text-align:center;">Product Name</th>
            <th style="text-align:center;">Product Model</th>
            <th style="text-align:center;">Serviced By</th>
        </tr>
	</thead>
    <tbody>
       <?php 
            $i=1;
        ?>
        <?php $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="text-align:center;"><?php echo e($i++); ?></td>
            
            <td style="text-align:center;"><?php echo e($claim->created_at); ?></td>
            <td style="text-align:center;"><?php echo e($claim->claim_serial); ?></td>
            <td style="text-align:center;"><?php echo e($claim->run_hour); ?></td>
            <td style="text-align:center;"><?php echo e($claim->comission_date); ?></td>
            <td style="text-align:center;"><?php echo e($claim->work_done_date); ?></td>
            <td style="text-align:center;" ><?php echo e($claim->company_name); ?> </td>
            <td style="text-align:center;"><?php echo e($claim->phone); ?></td>
            <td style="text-align:center;"><?php echo e($claim->serial_no); ?></td>
            <td style="text-align:center;"><?php echo e($claim->categoryName); ?></td>
            <td style="text-align:center;"><?php echo e($claim->productName); ?></td>
            <td style="text-align:center;"><?php echo e($claim->productModel); ?></td>
            <td style="text-align:center;"><?php echo e($claim->serviceBy); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
          
</table><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/exports/serviceList.blade.php ENDPATH**/ ?>