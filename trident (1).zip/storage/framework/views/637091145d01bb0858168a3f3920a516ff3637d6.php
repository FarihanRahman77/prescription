<?php $__env->startSection('content'); ?>

    <div class="container mt-1">
       
       <div class="w-100 mx-auto p-5 shadow scroll-sidebar">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <a class="btn btn-primary float-right" href="<?php echo e(route('warrenty_list_excel')); ?>"><i class="fa fa-file-excel-o"></i> EXEL</a>
                </div>
            </div>
           <h3 style="text-align:center;"><u>Registration List</u></h3>
            <div class="table-responsive">
               <table id="datatable2" width="100%" class="table table-bordered table-hover" style="font-size:13px;">
                   <thead>
                   <tr>
                       <th width="3%" >SL</th>
                       <th width="20%">Reg No</th>
                       <th width="8%">Installation Date</th>
                       <th width="23%">Customer Info</th>
                       <th width="15%">Product Info</th>
                       <th width="8%">Registered By</th>
                       <th width="8%">Warrenty</th>
                       <th width="12%">Application Type</th>
                       <th width="3%">Action</th>
                   </tr>
                   </thead>
                   <tbody style="font-size:12px;">
                       <?php 
                            $i=1;
                       ?>
                       <?php $__currentLoopData = $warrenties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warrenty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php 
                           $product=App\Models\Product::find($warrenty->product_id);
                           $warrenty_type=App\Models\WarrentyType::find($warrenty->warrenty_type);
                           $customer=App\Models\Customer::find($warrenty->customer_id);
                           ?>
                       <tr>
                           <td><?php echo e($i++); ?></td>
                           <td>Reg Serial: <?php echo e($warrenty->reg_id); ?><br> Reg No: <?php echo e($warrenty->registration_number); ?></td>
                           <td><?php echo e($warrenty->instalation_date); ?></td>
                           <td>Company Name: <?php echo e($customer->company_name); ?><br>Mobile: <?php echo e($customer->phone); ?><br>Address: <?php echo e($customer->address); ?>, <?php echo e($customer->city); ?>, <?php echo e($customer->country); ?></td>
                           <td>Name: <?php echo e($product->name); ?> - <?php echo e($product->model); ?> <br> Serial: <?php echo e($product->serial_no); ?> </td>
                           <td><?php echo e($warrenty->registered_by); ?></td>
                           <td><?php echo e($warrenty_type->type); ?></td>
                           <td><?php echo e($warrenty->application_type); ?></td>
                            <td style="width: 12%;">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                    <i class="fas fa-cog"></i>  <span class="caret"></span></button>
                                    <ul class="dropdown-menu dropdown-menu-right" style="border: 1px solid gray;" role="menu">
                                        <?php if(Auth::guard('web')->user()->can('Registration Details')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/details/registration',$warrenty->id)); ?>"><i class="fas fa-file-pdf"></i> Details </a></li>
                                        <?php endif; ?>
                                        <?php if(Auth::guard('web')->user()->can('Registration Attachment')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/attachment/registration',$warrenty->id)); ?>"><i class="fa-solid fa-paperclip"></i> Attachment </a></li>
                                        <?php endif; ?>
                                        <?php if(Auth::guard('web')->user()->can('Registration QR Code')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/generate/Warrenty/QR',$warrenty->id)); ?>"><i class="fa-solid fa-qrcode"></i> QR Code </a></li> 
                                        <?php endif; ?>
                                        <?php if(Auth::guard('web')->user()->can('Registration Edit')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/edit/registration',$warrenty->id)); ?>"><i class="fas fa-edit"></i> Edit </a></li>
                                        <?php endif; ?>
                                        <?php if(Auth::guard('web')->user()->can('Registration Delete')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/delete/registration',$warrenty->id)); ?>"><i class="fas fa-trash-alt"></i> Delete </a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                           
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
               </table>
             </div>




           <!-- Modal -->
           <div id="updateModal" class="modal fade" role="dialog">
               <div class="modal-dialog">

                   <!-- Modal content-->
                   <div class="modal-content">
                       <div class="modal-header">
                           <h4 class="modal-title">Update</h4>
                           <button type="button" class="close" data-dismiss="modal">&times;</button>
                       </div>
                       <div class="modal-body">
                           <div class="form-group">
                               <label for="name" >Employee Name</label>
                               <input type="text" class="form-control" id="emp_name" placeholder="Enter Employee name" required>
                           </div>
                           <div class="form-group">
                               <label for="email" >Email</label>
                               <input type="email" class="form-control" id="email" placeholder="Enter email">
                           </div>
                           <div class="form-group">
                               <label for="gender" >Gender</label>
                               <select id='gender' class="form-control">
                                   <option value='Male'>Male</option>
                                   <option value='Female'>Female</option>
                               </select>
                           </div>
                           <div class="form-group">
                               <label for="city" >City</label>
                               <input type="text" class="form-control" id="city" placeholder="Enter city">
                           </div>

                       </div>
                       <div class="modal-footer">
                           <input type="hidden" id="txt_empid" value="0">
                           <button type="button" class="btn btn-success btn-sm" id="btn_save">Save</button>
                           <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
                       </div>
                   </div>

               </div>
           </div>

       </div>
    </div>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
 <script type="text/javascript">
    
    $(document).ready( function () {
        $('#datatable2').DataTable();
    } );
    
    
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $(document).ready(function(){

            var table = $('#yajra-datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('get.search.data')); ?>",
                scrollY:        false,
                scrollX: true,
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                    {data: 'registration_number', name: 'registration_number'},
                    {data: 'serial_no', name: 'serial_no'},
                    {data: 'category_id', name: 'category_id'},
                    {data: 'product_id', name: 'product_id'},
                    {data: 'registered_by', name: 'registered_by'},
                    {data: 'instalation_date', name: 'instalation_date'},
                    {data: 'warrenty_type', name: 'warrenty_type'},
                    {data: 'application_type', name: 'application_type'},
                    {
                        data: 'action',
                        name: 'action',
                        orderable: true,
                        searchable: true
                    },
                ]
            });










            // // Update record
            // $('.updateUser').click(function(){
            //     var id = $(this).data('id');
            //
            //     $('#yajra-datatable').val(id);
            //
            //     alert( $('#txt_empid').val(id));

                // AJAX request
                
                
                
                
                
                

                

                
                
                
                

                
                
                
                
                
                

            // });

            // Save user
            
            

            
            
            
            

            

            
            
            
            
            
            
            
            
            

            
            
            
            

            
            

            
            
            
            
            
            
            

            
            
            
            

            // Delete record
            
            

            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            

            

        });





    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/warrenty/search/searchData.blade.php ENDPATH**/ ?>