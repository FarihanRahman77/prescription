<html>
    <head>
        <title>CERTIFICATE OF REGISTRATION</title>
       <?php echo $__env->make('backend.layouts.globalCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </head>
    <body>
       
        <header>
           
            <div class="columnCenter2">
                <img src="<?php echo e(asset('backend/image/logo.png')); ?>" class="reportLogo">
            </div>
            <div>
                 <img src="<?php echo e(asset('backend/image/logo.png')); ?>" class="reportWatermark"> 
            </div>
        </header>
        <footer>
            <div class="signatures">
                <div class="row">
                    <div class="columnRight">
                        Signed<br><?php echo e(@$setting->name); ?>

                    </div>
                    <div class="column"> 
                    <br><?php echo e(@$serviceWarrenty->created_at); ?>  
                    </div>
                                     
                </div><br><br><br>
                <hr />
                <div class="supAddressFont"><br><br><?php echo e(@$setting->report_footer); ?></div>
            </div>    
        </footer>
        <main class="waterMark">
            
            <div>
                <div style="text-align: center;">
                    <div class="citiestd13">
                        <b>CERTIFICATE OF REGISTRATION</b>
                    </div>
                </div>
                <div style="text-align: center;">
                    <p>This is to certify that the compressor detailed below has been registered as <br> a part of the Trident Agency Ltd Warranty Programme</p>
                </div>
                
               
            </div>
            
            <div class="main-table">
                <table border="1" class="custom-table" cellspacing="0" cellpadding="3">
                    <tbody>
                        <tr>
                            <td class="textLeft" width="50%">Registration Number:</td>
                            <td><?php echo e(@$serviceWarrenty->registration_number); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Registered Owner:</td>
                            <td><?php echo e(@$customer->company_name); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Address</td>
                            <td><?php echo e(@$customer->address); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Service Provider:</td>
                            <td><?php echo e(@$setting->name); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Provider Address:</td>
                            <td><?php echo e(@$setting->address); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Registered By:</td>
                            <td><?php echo e(@$serviceWarrenty->registered_by); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Serial Number:</td>
                            <td><?php echo e(@$product->serial_no); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Model:</td>
                            <td><?php echo e(@$product->model); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Warranty:</td>
                            <td><?php echo e(@$warrentyType->type); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Commissioned:</td>
                            <td><?php echo e(@$serviceWarrenty->instalation_date); ?></td>
                        </tr>
                        <tr>
                            <td class="textLeft">Warranty Expiry Date:</td>
                            <td><?php echo e(@$serviceWarrenty->expire_date); ?></td>
                        </tr>
                        
                        
                    </tbody>
                </table>
            </div>
        </main>


    </body>

</html>
<?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/warrenty/search/searchDetails.blade.php ENDPATH**/ ?>