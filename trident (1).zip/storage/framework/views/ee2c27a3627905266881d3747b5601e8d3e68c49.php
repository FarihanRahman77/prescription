  <div class="container mt-3 ml-3">
    <div class="row">
        <div class="col-md-2"><img src="<?php echo e(asset('backend/image/logo.png')); ?>" alt="" width="200px"></div>
        <div class="col-md-10"><p class="h2 text-right  m-2 p-2">Trident Agency Ltd.</p></div>
    </div>
  </div>

    <nav class="navbar navbar-expand-lg navbar-white bg-light">
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav m-auto">
            <li class="nav-item active">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <?php if(Auth::guard('web')->user()->can('Registration')): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Registration
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php if(Auth::guard('web')->user()->can('Registration Create')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('warrenty.add.registration')); ?>">New Registration</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Registration List')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('search.view')); ?>">All Registration</a>
                    <?php endif; ?>
                </div>
            </li>
            <?php endif; ?>
            <!---- Claims-->
            <?php if(Auth::guard('web')->user()->can('Claim')): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Warrenty Claims
                </a>
                
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php if(Auth::guard('web')->user()->can('Claim Create')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('newClaim')); ?>">New Claim</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Claim List')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('allClaim')); ?>">All Claim</a>
                    <?php endif; ?>
                </div>
            </li>
            <?php endif; ?>
            
            <!---- services-->
            <?php if(Auth::guard('web')->user()->can('Service')): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Services
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php if(Auth::guard('web')->user()->can('Service Create')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('create_service')); ?>">Add Service</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Service List')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('service_list')); ?>">Service List</a>
                    <?php endif; ?>
                </div>
            </li>
            <?php endif; ?>
            
           <?php if(Auth::guard('web')->user()->can('User')): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    User Management
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php if(Auth::guard('web')->user()->can('User Create')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Add</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('User List')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('user_list')); ?>">User List</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Roles')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('roles_list')); ?>">Roles</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Permission')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('permissions_list')); ?>">Permissions</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Permission')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('role_to_permissions')); ?>">Role to Permissions</a>
                    <?php endif; ?>
                </div>
            </li>
            <?php endif; ?>
            <?php if(Auth::guard('web')->user()->can('Shop Setting')): ?>
             <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Settings
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <?php if(Auth::guard('web')->user()->can('Category')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('category')); ?>">Category</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Product')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('product')); ?>">Product</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Spare Parts')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('productParts')); ?>">Product Parts</a>
                    <?php endif; ?>
                    <?php if(Auth::guard('web')->user()->can('Employee')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('employees_list')); ?>">Employees</a>
                    <?php endif; ?>
                    <?php if(Auth::user()->role == 'Super Admin'): ?> 
                    
                    <a class="dropdown-item" href="<?php echo e(route('shopSettingView')); ?>">Shop Setting</a>
                    <?php endif; ?>
                </div>
            </li>
            <?php endif; ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Log Off
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <!---  <a class="dropdown-item" href="#">Change Password</a>--->
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    Log out
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
              </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(Auth::user()->name); ?>

                </a>
            </li>
          </ul>
        </div>
    </nav>
<?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/layouts/topbar.blade.php ENDPATH**/ ?>