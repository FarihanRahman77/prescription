<!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('/backend/js/bootstrap.min.js')); ?>" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script> -->

<script src="<?php echo e(asset('/backend/js/jquery-3.5.1.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('backend/js/jquery.min.js')); ?>" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>


<script src="<?php echo e(asset('/backend/js/datatables.min.js')); ?>" crossorigin="anonymous"></script>
<!-- <script src="<?php echo e(asset('/backend/js/bootstrap5.min.js')); ?>" crossorigin="anonymous"></script> -->
<script src="<?php echo e(asset('/backend/js/select2.min.js')); ?>"></script>




<?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/layouts/javascript.blade.php ENDPATH**/ ?>