


<?php $__env->startSection('content'); ?>
 <div class="container">
        <div class="row">
            <div class=" col-md-9 content border border-secondary w-75 h-auto m-auto">
                <h5 class="text-center text-dark text-decoration-underline ">Create and Print QR codes for Parts</h5>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <span>Important Note: Please follow the stages below in order. To perform a new search please press the reset button here:</span><br>
                        <label  class="form-label">Step 1. Select Serial Number</label>
                        <select class="form-select" id="serial_no" name="serial_no" onchange="getWarrentyInfo()" required>
                            <option selected>Select Serial No.</option>
                            <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($registration->id); ?>"><?php echo e($registration->serial_no); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12" id="serial_info_div"></div>
                    
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>

     $(document).ready(function() {
        $('#serial_no').select2();
    });
    
    function getWarrentyInfo(){
        var serial_no=$('#serial_no').val();
         $.ajax({
                url:"<?php echo e(route('get.warrenty.info')); ?>",
                method: "GET",
                data: {
                    "serial_no":serial_no
                },
                success: function (result) {
                 //   alert(JSON.stringify(result));
                   $('#serial_info_div').html(result);
                }, error: function(response) {
                 //   alert(JSON.stringify(response));

                }, beforeSend: function () {
                    $('#loading').show();
                },complete: function () {
                    $('#loading').hide();
                }
            });
    }
    
    function showRegistrationInfo(id){
      window.location.href=("<?php echo e(url('/get/registration/info')); ?>" + "/" + id);
        
    }
    function showRegisteredServiceRepair(id){
         window.location.href=("<?php echo e(url('/get/Registered/Service/Repair')); ?>" + "/" + id);
    }
    function addClaimInfo(id){
         window.location.href=("<?php echo e(url('/create/new/claim/page/one')); ?>" + "/" + id);
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/claims/createClaim.blade.php ENDPATH**/ ?>