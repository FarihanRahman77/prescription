<table style="table-layout: auto;width: 100%;">
	<thead>
	    	<tr><td colspan="13" style="text-align: center;"> <?php echo e(@$setting->name); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> <?php echo e(@$setting->address); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Hotline: <?php echo e(@$setting->phone); ?></td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Email: <?php echo e(@$setting->email); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Fax: <?php echo e(@$setting->fax); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> </td></tr>
		<tr>
            <th style="text-align:center;">Sl.</th>
            <th style="text-align:center;">Description</th>
            <th style="text-align:center;">Parts NO</th>
            <th style="text-align:center;">Category</th>
            <th style="text-align:center;">Model</th>
            <th style="text-align:center;">Purchase Price</th>
            <th style="text-align:center;">Sale Price</th>
            <th style="text-align:center;">Status</th>
        </tr>
	</thead>
    <tbody>
        <?php 
            $i=1;
            $category='';
        ?>
        <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $category= App\Models\Category::where('id','=',$part->category_id)->first();
                $stock= App\Models\Stock::where('product_id','=',$part->id)->first();
            ?>
        <tr>
            <td style="text-align:center;"><?php echo e($i++); ?></td>
            
            <td style="text-align:center;"><?php echo e(@$part->name); ?></td>
            <td style="text-align:center;"><?php echo e(@$part->product_code); ?></td>
            <td style="text-align:center;"><?php echo e(@$category->name); ?></td>
            <td style="text-align:center;"><?php echo e(@$part->model); ?></td>
            <td style="text-align:center;"><?php echo e(@$part->purchase_price); ?></td>
            <td style="text-align:center;"><?php echo e(@$part->sale_price); ?></td>
            <td style="text-align:center;"><?php echo e(@$part->status); ?></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
          
</table><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/exports/sparePartsList.blade.php ENDPATH**/ ?>