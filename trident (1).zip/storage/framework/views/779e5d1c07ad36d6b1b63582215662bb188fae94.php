


<?php $__env->startSection('content'); ?>
 <div class="container">
        <div class="row">
            <div class=" col-md-12 content border border-secondary w-75 h-auto m-auto">
                <h5 class="text-center text-dark text-decoration-underline ">Spare Parts</h5>
                
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Auth::guard('web')->user()->can('Spare Parts Create')): ?>
                <a href="<?php echo e(route('add_spare_parts')); ?>" class="btn btn-primary float-right m-3"> + Add Spare Parts</a>
                <?php endif; ?>
                
              
                <a href="<?php echo e(route('spare_parts_list_excel')); ?>" class="btn btn-primary float-right m-3"><i class="fa fa-file-excel-o"></i> Excel</a>
                
                
                <table id="manageSparePartsTable" width="100%" class="table table-bordered  table-hover m-0">
                    <thead>
                        <tr>
                            <td width="5%" >SL.</td>
                            <td width="15%">Description</td>
                            <td width="10%">Parts No</td>
                            <td width="10%">Category</td>
                            <td width="10%">Model</td>
                            <td width="20%">Prices</td>
                            <td width="15%">Stock</td>
                            <td  width="8%">Status</td>
                            <td  width="7%">ACTION</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        $category='';
                        ?>
                        <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $category= App\Models\Category::where('id','=',$part->category_id)->first();
                                $stock= App\Models\Stock::where('product_id','=',$part->id)->first();
                            ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($part->name); ?></td>
                            <td><?php echo e($part->product_code); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($part->model); ?></td>
                            <td>Purchase Price:<?php echo e(@$part->purchase_price); ?> <br> Sale Price: <?php echo e(@$part->sale_price); ?></td>
                            <td>Opening Qty: <?php echo e($part->opening_qty ?? '0'); ?> <br> Stock Qty:<?php echo e($stock->qty ?? '0'); ?><br> Total Qty: <?php echo e(@$part->opening_qty + @$stock->qty); ?></td>
                            <td><?php echo e($part->status); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                        <i class="fas fa-cog"></i><span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-right" style="border: 1px solid gray;" role="menu">
                                        <?php if(Auth::guard('web')->user()->can('Spare Parts Edit')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/edit/spare/part',$part->id)); ?>"><i class="fas fa-edit"></i> Edit </a></li>
                                        <?php endif; ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/qr/code/spare/part',$part->id)); ?>"><i class="fa-solid fa-qrcode"></i> QR Code</a></li>
                                        <?php if(Auth::guard('web')->user()->can('Spare Parts Delete')): ?>
                                        <li class="action liDropDown"><a  class="btn" href="<?php echo e(url('/delete/spare/part',$part->id)); ?>"><i class="fas fa-trash-alt"></i> Delete </a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
    
    <script>
        $(document).ready( function () {
            $('#manageSparePartsTable').DataTable();
        } );
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>


<script>

     $(document).ready(function() {
        $('#serial_no').select2();
    });
    
    function showRegistrationInfo(id){
      window.open("<?php echo e(url('/get/registration/info')); ?>" + "/" + id);
        
    }
    
    function showRegisteredServiceRepair(id){
         window.open("<?php echo e(url('/get/Registered/Service/Repair')); ?>" + "/" + id);
    }
    
    function addClaimInfo(id){
         window.open("<?php echo e(url('/create/new/claim/page/one')); ?>" + "/" + id);
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/spareParts/partsList.blade.php ENDPATH**/ ?>