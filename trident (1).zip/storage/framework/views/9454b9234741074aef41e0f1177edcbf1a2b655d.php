<table style="table-layout: auto;width: 100%;">
	<thead>
	    	<tr><td colspan="13" style="text-align: center;"> <?php echo e(@$setting->name); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> <?php echo e(@$setting->address); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Hotline: <?php echo e(@$setting->phone); ?></td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Email: <?php echo e(@$setting->email); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> Fax: <?php echo e(@$setting->fax); ?> </td></tr>
	    	<tr><td colspan="13" style="text-align: center;"> </td></tr>
		<tr>
            <th style="text-align:center;">Sl</th>
            <th style="text-align:center;">Reg Date</th>
            <th style="text-align:center;">Reg Serial</th>
            <th style="text-align:center;">Reg No</th>
            
            <th style="text-align:center;">Company Name</th>
            <th style="text-align:center;">Customer Mobile</th>
            <th style="text-align:center;">Customer Email</th>
            <th style="text-align:center;">Customer Address</th>
            <th style="text-align:center;">Customer City</th>
            <th style="text-align:center;">Customer Country</th>
            <th style="text-align:center;">Product Name</th>
            <th style="text-align:center;">Product Model</th>
            <th style="text-align:center;">Product Serial</th>
            <th style="text-align:center;">Registered By</th>
            <th style="text-align:center;">Warrenty Type</th>
            <th style="text-align:center;">Application Type</th>
        </tr>
	</thead>
    <tbody>
       <?php 
            $i=1;
        ?>
        <?php $__currentLoopData = $warrenties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warrenty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
               $product=App\Models\Product::find($warrenty->product_id);
               $warrenty_type=App\Models\WarrentyType::find($warrenty->warrenty_type);
               $customer=App\Models\Customer::find($warrenty->customer_id);
            ?>
        <tr>
            <td style="text-align:center;"><?php echo e($i++); ?></td>
            
            <td style="text-align:center;"><?php echo e($warrenty->instalation_date); ?></td>
            <td style="text-align:center;"><?php echo e($warrenty->registration_number); ?></td>
            <td style="text-align:center;"><?php echo e($warrenty->reg_id); ?></td>
            <td style="text-align:center;"><?php echo e($customer->company_name); ?></td>
            <td style="text-align:center;"><?php echo e($customer->phone); ?></td>
            <td style="text-align:center;"><?php echo e($customer->email); ?></td>
            <td style="text-align:center;"><?php echo e($customer->address); ?></td>
            <td style="text-align:center;"><?php echo e($customer->city); ?></td>
            <td style="text-align:center;"><?php echo e($customer->country); ?></td>
            <td style="text-align:center;"><?php echo e($product->name); ?></td>
            <td style="text-align:center;"><?php echo e($product->model); ?></td>
            <td style="text-align:center;" ><?php echo e($product->serial_no); ?></td>
            <td style="text-align:center;"><?php echo e($warrenty->registered_by); ?></td>
            <td style="text-align:center;"><?php echo e($warrenty_type->type); ?></td>
            <td style="text-align:center;"><?php echo e($warrenty->application_type); ?></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
          
</table><?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/exports/WarrentyListExport.blade.php ENDPATH**/ ?>