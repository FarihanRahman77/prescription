<html>
    <head>
        <title>Employee QR code</title>
       <?php echo $__env->make('backend.layouts.globalCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </head>
    <body>
        <!-- Content Wrapper. Contains page content -->
        <header>
            
            <div class="columnCenter2">
               <img src="<?php echo e(asset('backend/image/logo.png')); ?>" class="reportLogo">
            </div>
            
        </header>
        <footer>
            <div class="signatures">
                <div class="row">
                    <div class="columnRight">
                        Signed<br><?php echo e(@$setting->name); ?>

                    </div>
                    <div class="column"> 
                    <br><?php echo e(@$serviceWarrenty->created_at); ?>  
                    </div>
                                     
                </div><br><br><br>
                <hr />
                <div class="supAddressFont"><br><br><?php echo e(@$setting->report_footer); ?></div>
            </div>    
        </footer>
        <main class="waterMark">
            
            <div>
                <div style="text-align: center;">
                    <div class="citiestd13">
                       
                        <b>QR code for <?php echo e($employee->designation); ?></b>
                    </div>
                </div>
                <div class="card-body">
                   <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(250)->generate($employee->token ?? ' ')); ?> " id="QrImage">
                </div>
                <br><br>
                <div class="citiestd13"> 
                    <b>Registration Number:</b><?php echo e(@$employee->name); ?><br>
                    <b>Serial Number:</b><?php echo e(@$employee->serial_no); ?>

                </div>
            </div>
        </main>
    </body>

</html>
<?php /**PATH /home/tridentcompresso/support.tridentcompressors.com/resources/views/backend/employee/employeeDetailsPdf.blade.php ENDPATH**/ ?>